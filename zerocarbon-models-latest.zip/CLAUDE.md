# zerocarbon-models

The models and tools behind ZeroCarbon Market.

- Product plan: https://claude.ai/artifact/AzFQB6h1DS5GYJkMzAcUqc
- Build plan: https://claude.ai/artifact/7ZUJrN7cjf2BWhmTH3crCU
- Data shapes: D:\ZeroCarbon\prompts\00-shared\contracts.md

## What this repo is

A Python service that makes every number ZeroCarbon Market shows: land scans, credit and money ranges, ZeroCarbon Score, and ZeroCarbon Comply forecasts. One codebase serves them two ways:

- a REST API (FastAPI) for the Replit website, and
- an MCP server that AgenticOrg registers as the Remote MCP connector `zerocarbon_models`.

## Rules

- Every number comes from tested code. No LLM calls inside this repo.
- Every estimate returns a range: low, likely, high. Never a single number.
- Credits count new growth only: this year's stored carbon minus last year's, minus the baseline, minus leakage, then minus the buffer (a parameter, 15 to 20%). Trees already standing earn nothing.
- Units go in every name: `dbh_cm`, `height_m`, `agb_kg`, `co2_t`, `price_inr_per_t`.
- Coefficients live in `data/*.json`, each with a `"source"` and `"verified": false` until checked. Never hard-code them, and never invent one: leave it null and say so.
- Every response carries `"demo": true` until its data is real.
- `contracts/` is the source of truth for every shape. Change a contract only with a version bump, and say so in the README.
- Satellite and map data only from sources that need no account (Microsoft Planetary Computer, AWS open data, public buckets). Never create an account or download gated data; stop and ask instead.
- Keys live in `.env`, which is git-ignored. Never commit a key.
- Push to GitHub only when the user says so.
- "ZeroCarbon" is the company's name, not a claim. No text this service returns may tell a user they are zero carbon, carbon neutral or net zero.

## Layout

- `contracts/`: JSON Schemas and one example per shape
- `zerocarbon_models/`: the models and tools
- `data/`: species, fees, rules, word lists, prices, pre-loaded map layers
- `api/`: the REST app and the MCP server
- `eval/`: hand-checked plots, back-tests, timings
- `tests/`: pytest

## Commands

- Tests: `pytest`
- Service (REST and MCP together): `uvicorn api.main:app --reload`
