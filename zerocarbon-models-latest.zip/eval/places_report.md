# ZeroCarbon Scan: check on known places

7 of 8 verdicts as expected. Slowest scan: 4.1 s.

| Place | Type | Verdict | As expected | Likely tCO2e/yr (1 ha) | Reasons | Time |
| --- | --- | --- | --- | --- | --- | --- |
| Bandipur National Park | forest | not_eligible | yes | - | About 87% is already under trees; trees already standing earn nothing | 4.1 s |
| Nagarhole National Park | forest | not_eligible | yes | - | About 100% is already under trees; trees already standing earn nothing | 3.8 s |
| Krishna Raja Sagara reservoir (open water) | water | not_eligible | yes | - | Mostly open water | 2.1 s |
| Tungabhadra reservoir (open water) | water | not_eligible | yes | - | Mostly open water | 2.6 s |
| Central Bengaluru (Gandhinagar, near Majestic) | town | not_eligible | yes | - | Mostly buildings or roads | 2.3 s |
| Central Mysuru | town | not_eligible | yes | - | Mostly buildings or roads | 2.0 s |
| Irrigated fields near Mandya | farmland | likely_eligible | yes | 10.47 | Mostly farmland with few trees in recent years | 2.2 s |
| Farmland in Chikkaballapur district | farmland | needs_checks | NO | 10.47 | About 54% is already under trees; trees already standing earn nothing | 2.0 s |

Expected: forest is not eligible or needs checks; water and town are not eligible; farmland is likely eligible.
