"""ZeroCarbon Scan: can this land earn credits, by which method, and roughly how much."""
from __future__ import annotations

import json
from collections import OrderedDict

from . import growth, layers, tools
from .config import load_json

SCAN_WAIT_S = 6.5
SCAN_LAYERS = ("worldcover", "io_lulc", "water")

SPECIES_WHY = {
    "melia_dubia": "Fast-growing plantation tree common in Karnataka",
    "teak": "Long-lived timber tree widely planted in Karnataka",
}


def _in_karnataka(lat: float, lon: float, box: dict) -> bool:
    return box["lat_min"] <= lat <= box["lat_max"] and box["lon_min"] <= lon <= box["lon_max"]


def _latest(by_year: dict | None) -> float | None:
    if not by_year:
        return None
    return by_year[max(by_year, key=int)]


def _decide(s: dict, rules: dict, lon: float) -> tuple[str, str | None, list[str]]:
    wc = s.get("worldcover")
    if wc is None and not s.get("trees_by_year"):
        return "needs_checks", None, ["Satellite data could not be read; try again in a minute"]
    wc = wc or {}
    trees_now = max(wc.get("trees", 0.0), _latest(s.get("trees_by_year")) or 0.0)
    water_occ = s.get("water_occurrence_pct") or 0.0
    wetland = wc.get("wetland", 0.0) + wc.get("mangrove", 0.0)

    if wc.get("built", 0.0) > rules["built_max"]:
        return "not_eligible", None, ["Mostly buildings or roads"]
    if wc.get("water", 0.0) > rules["water_max"] or water_occ > rules["water_occurrence_max_pct"]:
        return "not_eligible", None, ["Mostly open water"]
    if wetland > rules["wetland_min"]:
        if lon <= rules["coastal_lon_max"]:
            return "needs_checks", "BM FR05.001", ["Coastal wetland: the mangrove method may fit; needs a site check"]
        return "not_eligible", None, ["Wetland: the tree-planting method does not cover wetlands"]
    if trees_now > rules["trees_now_max"]:
        verdict = "not_eligible" if trees_now > 0.6 else "needs_checks"
        return verdict, None, [f"About {round(trees_now * 100)}% is already under trees; trees already standing earn nothing"]
    history = s.get("trees_by_year") or {}
    past = [(y, v) for y, v in history.items() if v is not None and v > rules["trees_history_max"]]
    if past:
        year = min(int(y) for y, _ in past)
        return "needs_checks", "BM FR05.002", [f"Had tree cover in {year}; the land-history rule must be checked"]

    reasons = []
    if wc.get("cropland", 0.0) >= 0.5:
        reasons.append("Mostly farmland with few trees in recent years")
    else:
        reasons.append("Open land with few trees in recent years")
    return "likely_eligible", "BM FR05.002", reasons


# Recent satellite reads, so a pin scanned again answers at once and the small server is not swamped.
_SUMMARIES: OrderedDict = OrderedDict()


def _summary(lat: float, lon: float, boundary_geojson: dict | None) -> dict:
    key = (round(lat, 5), round(lon, 5), json.dumps(boundary_geojson, sort_keys=True) if boundary_geojson else None)
    if key in _SUMMARIES:
        _SUMMARIES.move_to_end(key)
        return _SUMMARIES[key]
    s = layers.land_summary(lat, lon, boundary_geojson, timeout_s=SCAN_WAIT_S, only=SCAN_LAYERS)
    if s.get("errors") == {}:
        _SUMMARIES[key] = s
        while len(_SUMMARIES) > 512:
            _SUMMARIES.popitem(last=False)
    return s


def scan_land(lat: float, lon: float, boundary_geojson: dict | None = None) -> dict:
    rules = load_json("scan_rules")
    # Elevation reads take 5-20 s and only feed the "steep land" note, so the scan skips them for now.
    s = _summary(lat, lon, boundary_geojson)
    unreadable = s.get("worldcover") is None
    area = round(s.get("area_ha") or 1.0, 2)
    in_state = _in_karnataka(lat, lon, rules["karnataka_bbox"])

    verdict, method, reasons = _decide(s, rules, lon)
    if not in_state:
        verdict = "needs_checks" if verdict != "not_eligible" else verdict
        reasons = ["Scan covers Karnataka today"] + reasons
    slope = s.get("slope_deg")
    if slope is not None and slope > rules["steep_slope_deg"] and verdict != "not_eligible":
        reasons.append("Steep land: planting will cost more")

    wc = s.get("worldcover") or {}
    known = {k: round(wc.get(k, 0.0), 3) for k in ("cropland", "trees", "built", "water")}
    land_cover = {**known, "other": round(max(0.0, 1.0 - sum(known.values())), 3)}
    existing = round(max(wc.get("trees", 0.0), _latest(s.get("trees_by_year")) or 0.0), 3)

    species_keys = rules["default_species"]
    species = [{"name": load_json("species")["species"][k]["name"], "why": SPECIES_WHY.get(k, "Suits this area")} for k in species_keys]
    unseen = list(rules["unseen"])

    credits = money = None
    route_first_year, route_yearly = None, None
    if verdict != "not_eligible" and not unreadable:
        try:
            est = growth.estimate(species_keys[0], area_ha=area, years=10)
            avg = est["average_per_year_co2_t"]
            credits = {**avg, "unit": "tCO2e"}
            price = load_json("prices")["landowner_price_inr_per_t"]
            money = {
                "low": round(avg["low"] * price["low"]),
                "likely": round(avg["likely"] * price["likely"]),
                "high": round(avg["high"] * price["high"]),
                "basis": "demo price band, before fees",
            }
        except (ValueError, KeyError) as e:
            unseen.append(f"Growth estimate unavailable: {e}")
    costs = tools.route_costs(area, credits["likely"] if credits else 0.0)
    offset = next(r for r in costs["routes"] if r["route"] == "india_offset")
    route_first_year, route_yearly = offset["fees_inr_first_year"], offset["fees_inr_yearly"]

    return {
        "version": "1.0",
        "demo": True,
        "location": {"lat": lat, "lon": lon, "area_ha": area, "state": "Karnataka" if in_state else None},
        "verdict": verdict,
        "reasons": reasons[:3],
        "method": method,
        "land_cover": land_cover,
        "existing_tree_cover": existing,
        "species": species if verdict != "not_eligible" else [],
        "credits_per_year": credits,
        "money_inr": money,
        "fixed_costs_inr": {"first_year": route_first_year, "yearly": route_yearly},
        "unseen": unseen,
    }
