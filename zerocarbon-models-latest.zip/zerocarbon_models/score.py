"""ZeroCarbon Score: start at 100 and subtract points for each integrity flag."""
from __future__ import annotations

from shapely.geometry import shape

from .config import load_json
from .tools import _fetch_listings

HARVESTED = {"melia dubia", "melia_dubia", "eucalyptus", "poplar", "casuarina", "teak", "tectona grandis"}


def _overlap_share(a: dict, b: dict) -> float:
    ga, gb = shape(a), shape(b)
    if ga.area == 0:
        return 0.0
    return ga.intersection(gb).area / ga.area


def score_listing(
    listing_id: str,
    status: str = "issued",
    boundary_geojson: dict | None = None,
    serials: str | None = None,
    issued_on: str | None = None,
    species: str | None = None,
    documents: list[str] | None = None,
    delivery_year: int | None = None,
    long_term_average_cap: bool = False,
    tree_cover_by_year: dict | None = None,
) -> dict:
    weights = load_json("score_weights")
    required = load_json("required_documents")
    flags = []

    def flag(code: str, detail: str) -> None:
        flags.append({"code": code, "detail": detail, "points": weights[code]})

    others = [x for x in _fetch_listings() if x.get("id") != listing_id]
    if boundary_geojson:
        for other in others:
            ob = other.get("boundary_geojson")
            if ob and _overlap_share(boundary_geojson, ob) > 0.05:
                flag("boundary_overlap", f"The boundary overlaps listing {other['id']}.")
                break
    if serials:
        for other in others:
            if other.get("serials") and other["serials"] == serials:
                flag("double_listing", f"The same serial numbers are in listing {other['id']}.")
                break
    if issued_on and tree_cover_by_year:
        year = int(str(issued_on)[:4])
        before = [v for y, v in tree_cover_by_year.items() if int(y) <= year and v is not None]
        after = [v for y, v in tree_cover_by_year.items() if int(y) > year and v is not None]
        if before and after and max(before) - min(after) > 0.2:
            flag("tree_loss_after_issuance", "Tree cover fell by more than 20 points after the credits were issued.")
    if species and species.lower() in HARVESTED and not long_term_average_cap:
        flag("harvest_uncapped", f"{species} is usually cut and sold; credits must be capped at the long-term average.")
    needed = required["future"] if status == "future" else required["issued"]
    have = {d.lower() for d in (documents or [])}
    missing = [d for d in needed if d.lower() not in have]
    if missing:
        flag("missing_documents", "Missing: " + "; ".join(missing) + ".")
    if status == "future" and not delivery_year:
        flag("future_without_delivery_year", "A future listing must say the year the credits will be delivered.")

    score = max(0, 100 - sum(f["points"] for f in flags))
    return {"listing_id": listing_id, "score": score, "flags": flags, "demo": True}
