"""Paths, keys and data-file loading shared by every module."""
from __future__ import annotations

import json
import os
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"

load_dotenv(ROOT / ".env")


def env(name: str, default: str | None = None) -> str | None:
    return os.environ.get(name, default)


@lru_cache(maxsize=None)
def load_json(name: str) -> dict:
    """Read data/<name>.json once; raise a clear error if it is missing."""
    path = DATA / f"{name}.json"
    if not path.exists():
        raise FileNotFoundError(f"data file missing: {path}")
    with path.open(encoding="utf-8") as f:
        return json.load(f)


def load_text(name: str) -> str:
    return (DATA / name).read_text(encoding="utf-8")
