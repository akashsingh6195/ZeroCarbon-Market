"""On-demand land summary for one plot, read from Microsoft Planetary Computer.

`land_summary(lat, lon, boundary_geojson=None)` reads only the small window of
each cloud-optimised GeoTIFF that covers the plot (no bulk downloads, no
account, no key: Planetary Computer signs blob URLs anonymously).

Layers (STAC collection id -> asset):

- ``esa-worldcover`` -> ``map``: ESA WorldCover 10 m, 2021 (v200) item.
  Fractions of the plot in each class.
- ``io-lulc-annual-v02`` -> ``data``: Impact Observatory annual 10 m land
  cover, 2017 onward. Fraction of trees and of crops per year.
- ``jrc-gsw`` -> ``occurrence``: JRC Global Surface Water, how often each
  pixel was water 1984-2020 (0-100 %). Mean over the plot.
- ``cop-dem-glo-30`` -> ``data``: Copernicus DEM GLO-30. Mean elevation (m)
  and mean slope (degrees). It is a surface model, so tree tops and roofs
  are included in the height.

The four layers run in parallel threads. Each has a time limit; a layer that
fails or runs out of time is recorded in ``errors`` and the others still
return.
"""

from __future__ import annotations

import math
import time
from concurrent.futures import ThreadPoolExecutor, wait
from typing import Any, Callable

import numpy as np
import planetary_computer
import rasterio
import requests
from rasterio.features import geometry_mask
from rasterio.warp import transform_geom
from rasterio.windows import Window
from shapely.geometry import shape

STAC_URL = "https://planetarycomputer.microsoft.com/api/stac/v1"
LAYER_TIMEOUT_S = 20.0
STAC_TIMEOUT_S = 10.0
DEFAULT_SIDE_M = 100.0  # 100 m x 100 m = 1 ha

WGS84 = "EPSG:4326"

# GDAL settings for fast, small range reads of cloud-optimised GeoTIFFs.
GDAL_ENV = {
    "GDAL_DISABLE_READDIR_ON_OPEN": "EMPTY_DIR",
    "CPL_VSIL_CURL_ALLOWED_EXTENSIONS": ".tif,.tiff,.TIF",
    "GDAL_HTTP_MERGE_CONSECUTIVE_RANGES": "YES",
    "GDAL_HTTP_MULTIPLEX": "YES",
    "GDAL_HTTP_VERSION": "2",
    "GDAL_INGESTED_BYTES_AT_OPEN": "65536",
    "VSI_CACHE": "TRUE",
    "GDAL_HTTP_TIMEOUT": "6",
    "GDAL_HTTP_CONNECTTIMEOUT": "4",
    "GDAL_HTTP_MAX_RETRY": "1",
    "GDAL_HTTP_RETRY_DELAY": "0.5",
}

# ESA WorldCover class codes -> output keys. Anything else goes to "other".
WORLDCOVER_CLASSES = {
    10: "trees",
    20: "shrub",
    30: "grass",
    40: "cropland",
    50: "built",
    60: "bare",
    80: "water",
    90: "wetland",
    95: "mangrove",
}
WORLDCOVER_KEYS = list(WORLDCOVER_CLASSES.values()) + ["other"]  # snow 70, moss 100
WORLDCOVER_YEAR = "2021"

# Impact Observatory annual land cover (io-lulc-annual-v02).
IO_NODATA = 0
IO_TREES = 2
IO_CROPS = 5
IO_CLOUDS = 10  # left out of the count: the ground was not seen

GSW_MAX_VALID = 100  # occurrence is 0..100; larger values are no-data


# --------------------------------------------------------------------------
# Plot geometry
# --------------------------------------------------------------------------


def metres_per_degree(lat_deg: float) -> tuple[float, float]:
    """Length of one degree of latitude and of longitude, in metres, on WGS84."""
    p = math.radians(lat_deg)
    m_lat = 111132.92 - 559.82 * math.cos(2 * p) + 1.175 * math.cos(4 * p) - 0.0023 * math.cos(6 * p)
    m_lon = 111412.84 * math.cos(p) - 93.5 * math.cos(3 * p) + 0.118 * math.cos(5 * p)
    return m_lat, m_lon


def square_plot(lat: float, lon: float, side_m: float = DEFAULT_SIDE_M) -> dict:
    """A GeoJSON Polygon (lon/lat) for a square of `side_m` metres centred on the point."""
    m_lat, m_lon = metres_per_degree(lat)
    half_lat = (side_m / 2.0) / m_lat
    half_lon = (side_m / 2.0) / m_lon
    w, e = lon - half_lon, lon + half_lon
    s, n = lat - half_lat, lat + half_lat
    return {
        "type": "Polygon",
        "coordinates": [[[w, s], [e, s], [e, n], [w, n], [w, s]]],
    }


def area_ha(geom: dict) -> float:
    """Area of a lon/lat GeoJSON polygon in hectares.

    Projects to an equal-area (Lambert azimuthal) projection centred on the
    polygon, then measures it there.
    """
    c = shape(geom).centroid
    laea = f"+proj=laea +lat_0={c.y} +lon_0={c.x} +datum=WGS84 +units=m +no_defs"
    projected = shape(transform_geom(WGS84, laea, geom))
    return projected.area / 10_000.0


def _plot_geometry(lat: float, lon: float, boundary_geojson: dict | None) -> dict:
    if boundary_geojson is None:
        return square_plot(lat, lon)
    geom = boundary_geojson
    if geom.get("type") == "Feature":
        geom = geom["geometry"]
    elif geom.get("type") == "FeatureCollection":
        feats = geom.get("features") or []
        if len(feats) != 1:
            raise ValueError("boundary FeatureCollection must hold exactly one feature")
        geom = feats[0]["geometry"]
    if geom.get("type") not in ("Polygon", "MultiPolygon"):
        raise ValueError(f"boundary must be a Polygon or MultiPolygon, got {geom.get('type')!r}")
    if not shape(geom).is_valid:
        raise ValueError("boundary polygon is not valid (self-intersecting or empty)")
    return geom


# --------------------------------------------------------------------------
# STAC search and window reads
# --------------------------------------------------------------------------


def _search(collection: str, geom: dict, datetime: str | None = None) -> list[dict]:
    """STAC items of `collection` that intersect `geom`, as plain dicts."""
    body: dict[str, Any] = {"collections": [collection], "intersects": geom, "limit": 100}
    if datetime:
        body["datetime"] = datetime
    r = requests.post(f"{STAC_URL}/search", json=body, timeout=STAC_TIMEOUT_S)
    r.raise_for_status()
    feats = r.json().get("features", [])
    if not feats:
        raise LookupError(f"no {collection} item covers this plot")
    return feats


def _href(item: dict, asset: str) -> str:
    try:
        href = item["assets"][asset]["href"]
    except KeyError as exc:
        raise KeyError(f"item {item.get('id')} has no asset {asset!r}") from exc
    return planetary_computer.sign(href)


def _read_window(href: str, geom_wgs84: dict, pad: int = 0):
    """Read the window of a COG that covers the plot.

    Returns (data, inside, transform) where `data` is a masked array (mask =
    no-data), `inside` is True for pixels inside the plot, and `transform`
    is the window's affine transform. Returns None if the plot does not
    overlap this file.
    """
    with rasterio.Env(**GDAL_ENV):
        with rasterio.open(href) as src:
            g = transform_geom(WGS84, src.crs, geom_wgs84)
            left, bottom, right, top = shape(g).bounds
            inv = ~src.transform  # map x/y -> column/row
            corners = ((left, bottom), (left, top), (right, bottom), (right, top))
            cols = [inv.a * x + inv.b * y + inv.c for x, y in corners]
            rows = [inv.d * x + inv.e * y + inv.f for x, y in corners]
            c0 = max(int(math.floor(min(cols))) - pad, 0)
            r0 = max(int(math.floor(min(rows))) - pad, 0)
            c1 = min(int(math.ceil(max(cols))) + pad, src.width)
            r1 = min(int(math.ceil(max(rows))) + pad, src.height)
            if c1 <= c0 or r1 <= r0:
                return None
            win = Window(c0, r0, c1 - c0, r1 - r0)
            data = src.read(1, window=win, masked=True)
            wt = src.window_transform(win)
    inside = geometry_mask([g], out_shape=data.shape, transform=wt, invert=True)
    if not inside.any():  # plot smaller than a pixel: take the pixels it touches
        inside = geometry_mask([g], out_shape=data.shape, transform=wt, invert=True, all_touched=True)
    return data, inside, wt


def _plot_values(href: str, geom: dict) -> np.ndarray:
    """1-D array of valid (not no-data) pixel values inside the plot."""
    res = _read_window(href, geom)
    if res is None:
        return np.empty(0)
    data, inside, _ = res
    keep = inside & ~np.ma.getmaskarray(data)
    return np.asarray(data.data[keep])


def _parallel(fn: Callable, args_list: list, max_workers: int = 8) -> list:
    if len(args_list) == 1:
        return [fn(*args_list[0])]
    with ThreadPoolExecutor(max_workers=min(max_workers, len(args_list))) as pool:
        return list(pool.map(lambda a: fn(*a), args_list))


# --------------------------------------------------------------------------
# The four layers
# --------------------------------------------------------------------------


def _layer_worldcover(geom: dict) -> dict:
    items = _search("esa-worldcover", geom, datetime=f"{WORLDCOVER_YEAR}-01-01/{WORLDCOVER_YEAR}-12-31")
    items = [i for i in items if (i["properties"].get("start_datetime") or "")[:4] == WORLDCOVER_YEAR]
    if not items:
        raise LookupError(f"no esa-worldcover {WORLDCOVER_YEAR} item covers this plot")
    parts = _parallel(_plot_values, [(_href(i, "map"), geom) for i in items])
    vals = np.concatenate(parts) if parts else np.empty(0)
    vals = vals[vals != 0]  # 0 is no-data
    if vals.size == 0:
        raise ValueError("esa-worldcover has no valid pixels inside the plot")
    out = {k: 0.0 for k in WORLDCOVER_KEYS}
    codes, counts = np.unique(vals, return_counts=True)
    for code, n in zip(codes.tolist(), counts.tolist()):
        out[WORLDCOVER_CLASSES.get(int(code), "other")] += n
    total = float(vals.size)
    return {"worldcover": {k: round(v / total, 4) for k, v in out.items()}}


def _layer_io_lulc(geom: dict) -> dict:
    items = _search("io-lulc-annual-v02", geom)
    jobs = []
    for it in items:
        year = (it["properties"].get("start_datetime") or "")[:4]
        if year.isdigit():
            jobs.append((year, _href(it, "data")))
    if not jobs:
        raise LookupError("no io-lulc-annual-v02 items with a year cover this plot")
    parts = _parallel(lambda y, h: (y, _plot_values(h, geom)), jobs, max_workers=8)
    by_year: dict[str, list[np.ndarray]] = {}
    for year, vals in parts:
        by_year.setdefault(year, []).append(vals)
    trees, crops = {}, {}
    for year in sorted(by_year):
        vals = np.concatenate(by_year[year])
        vals = vals[(vals != IO_NODATA) & (vals != IO_CLOUDS)]
        if vals.size == 0:
            trees[year] = crops[year] = None
            continue
        trees[year] = round(float(np.mean(vals == IO_TREES)), 4)
        crops[year] = round(float(np.mean(vals == IO_CROPS)), 4)
    return {"trees_by_year": trees, "crops_by_year": crops}


def _layer_water(geom: dict) -> dict:
    items = _search("jrc-gsw", geom)
    parts = _parallel(_plot_values, [(_href(i, "occurrence"), geom) for i in items])
    vals = np.concatenate(parts).astype(float) if parts else np.empty(0)
    vals = vals[(vals >= 0) & (vals <= GSW_MAX_VALID)]
    if vals.size == 0:
        raise ValueError("jrc-gsw has no valid pixels inside the plot")
    return {"water_occurrence_pct": round(float(vals.mean()), 2)}


def _dem_part(href: str, geom: dict, lat: float) -> tuple[np.ndarray, np.ndarray]:
    """Elevations and slopes (degrees) of DEM pixels inside the plot, for one tile."""
    res = _read_window(href, geom, pad=1)  # one pixel of margin for the slope
    if res is None:
        return np.empty(0), np.empty(0)
    data, inside, wt = res
    z = np.ma.filled(data.astype(float), np.nan)
    m_lat, m_lon = metres_per_degree(lat)
    dx_m = abs(wt.a) * m_lon
    dy_m = abs(wt.e) * m_lat
    if z.shape[0] >= 2 and z.shape[1] >= 2:
        dz_dy, dz_dx = np.gradient(z, dy_m, dx_m)
        slope = np.degrees(np.arctan(np.hypot(dz_dx, dz_dy)))
    else:
        slope = np.full(z.shape, np.nan)
    ok = inside & np.isfinite(z)
    return z[ok], slope[ok & np.isfinite(slope)]


def _layer_dem(geom: dict) -> dict:
    items = _search("cop-dem-glo-30", geom)
    lat = shape(geom).centroid.y
    parts = _parallel(_dem_part, [(_href(i, "data"), geom, lat) for i in items])
    elev = np.concatenate([p[0] for p in parts])
    slope = np.concatenate([p[1] for p in parts])
    if elev.size == 0:
        raise ValueError("cop-dem-glo-30 has no valid pixels inside the plot")
    return {
        "elevation_m": round(float(elev.mean()), 1),
        "slope_deg": round(float(slope.mean()), 2) if slope.size else None,
    }


LAYERS: dict[str, tuple[Callable[[dict], dict], tuple[str, ...]]] = {
    "worldcover": (_layer_worldcover, ("worldcover",)),
    "io_lulc": (_layer_io_lulc, ("trees_by_year", "crops_by_year")),
    "water": (_layer_water, ("water_occurrence_pct",)),
    "dem": (_layer_dem, ("elevation_m", "slope_deg")),
}


# --------------------------------------------------------------------------
# Public entry point
# --------------------------------------------------------------------------


def _timed(fn: Callable[[dict], dict], geom: dict) -> tuple[dict | None, float, Exception | None]:
    """Run one layer; never raises, so its time is kept even when it fails."""
    t0 = time.perf_counter()
    try:
        return fn(geom), time.perf_counter() - t0, None
    except Exception as exc:  # one layer failing must not sink the others
        return None, time.perf_counter() - t0, exc


def land_summary(lat: float, lon: float, boundary_geojson: dict | None = None,
                 timeout_s: float = LAYER_TIMEOUT_S, only: tuple[str, ...] | None = None) -> dict:
    """Land cover, water history, elevation and slope for one plot.

    With no boundary the plot is a 100 m x 100 m square (1 ha) centred on
    (lat, lon). With a boundary (GeoJSON Polygon in lon/lat) that polygon is
    used and its area is measured. ``only`` limits the call to some of the
    LAYERS keys; the others come back as None without being read.
    """
    t_start = time.perf_counter()
    geom = _plot_geometry(lat, lon, boundary_geojson)

    result: dict[str, Any] = {
        "area_ha": round(area_ha(geom), 4),
        "worldcover": None,
        "trees_by_year": None,
        "crops_by_year": None,
        "water_occurrence_pct": None,
        "elevation_m": None,
        "slope_deg": None,
        "errors": {},
        "timings_s": {},
    }

    chosen = {name: spec for name, spec in LAYERS.items() if only is None or name in only}
    pool = ThreadPoolExecutor(max_workers=len(chosen), thread_name_prefix="land-layer")
    try:
        futures = {name: pool.submit(_timed, fn, geom) for name, (fn, _) in chosen.items()}
        wait(futures.values(), timeout=timeout_s)
        for name, fut in futures.items():
            if not fut.done():
                fut.cancel()
                result["errors"][name] = f"timed out after {timeout_s:.0f} s"
                result["timings_s"][name] = round(timeout_s, 2)
                continue
            out, secs, exc = fut.result()
            result["timings_s"][name] = round(secs, 2)
            if exc is not None:
                result["errors"][name] = f"{type(exc).__name__}: {exc}"
                continue
            for key in LAYERS[name][1]:
                result[key] = out.get(key)
    finally:
        pool.shutdown(wait=False, cancel_futures=True)

    result["timings_s"]["total"] = round(time.perf_counter() - t_start, 2)
    return result
