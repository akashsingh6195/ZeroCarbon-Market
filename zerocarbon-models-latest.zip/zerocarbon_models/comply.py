"""Compliance forecast: a plant's year-end emissions per tonne against its CCTS target."""
from __future__ import annotations

import numpy as np

from .config import load_json

FUELS = ("coal_t", "gas_scm", "power_kwh", "diesel_l")
Z90 = 1.2816  # 10th/90th percentile of a normal spread


def _month_emissions(month: dict, factors: dict) -> float:
    total = 0.0
    for fuel in FUELS:
        amount = month.get(fuel) or 0.0
        if amount:
            factor = factors[fuel]["value"]
            if factor is None:
                raise ValueError(f"emission factor for {fuel} is missing")
            total += amount * factor
    return total


def comply_forecast(plant_id: str, target: float, months: list[dict], expected_yearly_production_t: float | None = None) -> dict:
    if not months:
        raise ValueError("at least one month of data is needed")
    factors = load_json("emission_factors")["factors"]
    production = np.array([float(m["production_t"]) for m in months])
    if (production <= 0).any():
        raise ValueError("production_t must be above zero in every month")
    emissions = np.array([_month_emissions(m, factors) for m in months])
    intensity = emissions / production
    n = len(months)

    if n >= 3:
        x = np.arange(n)
        slope, intercept = np.polyfit(x, intensity, 1)
        resid = intensity - (slope * x + intercept)
        sigma = float(np.std(resid, ddof=2)) if n > 3 else float(np.std(resid))
        future = slope * np.arange(n, 12) + intercept
    else:
        sigma = float(np.std(intensity)) if n > 1 else 0.0
        future = np.full(max(12 - n, 0), intensity.mean())

    year = np.concatenate([intensity, future])[:12]
    likely = float(year.mean())
    remaining = max(12 - n, 0)
    spread = Z90 * sigma * np.sqrt(remaining) / 12 if remaining else 0.0
    forecast = {"low": round(likely - spread, 4), "likely": round(likely, 4), "high": round(likely + spread, 4)}

    yearly_production = expected_yearly_production_t or float(production.mean() * 12)
    shortfall = {k: round((v - target) * yearly_production) for k, v in forecast.items()}

    return {
        "plant_id": plant_id,
        "unit": "tCO2e per tonne of product",
        "intensity_now": round(float(intensity.mean()), 4),
        "target": target,
        "forecast_year_end": forecast,
        "shortfall_t": shortfall,
        "months_used": n,
        "demo": True,
    }
