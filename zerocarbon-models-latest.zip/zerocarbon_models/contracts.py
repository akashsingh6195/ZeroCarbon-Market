"""Load and check the data shapes in contracts/.

The JSON Schemas in contracts/ are the source of truth for every shape the
service sends or receives. This module finds them relative to the repo root,
so it works from any current directory.
"""
from __future__ import annotations

import copy
import json
from functools import lru_cache
from pathlib import Path

from jsonschema import Draft202012Validator
from jsonschema.exceptions import best_match

REPO_ROOT = Path(__file__).resolve().parent.parent
CONTRACTS_DIR = REPO_ROOT / "contracts"
EXAMPLES_DIR = CONTRACTS_DIR / "examples"
_SUFFIX = ".schema.json"


def names() -> list[str]:
    """Names of every contract, e.g. ["claim_check", "comply_forecast", ...]."""
    return sorted(p.name[: -len(_SUFFIX)] for p in CONTRACTS_DIR.glob(f"*{_SUFFIX}"))


def _path(folder: Path, name: str, suffix: str) -> Path:
    if name not in names():
        raise ValueError(f"{name}: unknown contract (known: {', '.join(names())})")
    return folder / f"{name}{suffix}"


@lru_cache(maxsize=None)
def _load_schema(name: str) -> dict:
    return json.loads(_path(CONTRACTS_DIR, name, _SUFFIX).read_text(encoding="utf-8"))


@lru_cache(maxsize=None)
def _validator(name: str) -> Draft202012Validator:
    s = _load_schema(name)
    Draft202012Validator.check_schema(s)
    return Draft202012Validator(s)


def schema(name: str) -> dict:
    """The JSON Schema for one contract (a copy; changing it changes nothing)."""
    return copy.deepcopy(_load_schema(name))


def example(name: str) -> dict:
    """A fresh copy of the example for one contract."""
    return json.loads(_path(EXAMPLES_DIR, name, ".json").read_text(encoding="utf-8"))


def _where(error) -> str:
    parts = [str(p) for p in error.absolute_path]
    return ".".join(parts) if parts else "top level"


def validate(name: str, obj) -> None:
    """Check obj against a contract. Raises ValueError("<name>: <reason>") if it does not fit."""
    v = _validator(name)
    errors = list(v.iter_errors(obj))
    if not errors:
        return
    first = best_match(errors)
    reason = f"{_where(first)}: {first.message}"
    if len(errors) > 1:
        reason += f" (and {len(errors) - 1} more problem{'s' if len(errors) > 2 else ''})"
    raise ValueError(f"{name}: {reason}")
