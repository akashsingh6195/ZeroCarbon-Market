"""Tree growth model: CO2 removed per year by new planting, as a low/likely/high range.

Two methods, chosen by what data/species.json holds:
- "growth_curve": Chapman-Richards curves fitted to height and dbh by age, the biomass equation,
  planting density and survival. Used when there are at least 3 ages and density and survival are known.
- "published_rate": a published CO2 removal rate per hectare per year, used when the curve data is thin.
Both cap harvested species at their long-term average stock and take off the buffer.
"""
from __future__ import annotations

from functools import lru_cache

import numpy as np
from scipy.optimize import curve_fit

from .config import load_json

DRAWS = 1000
SEED = 42


def chapman_richards(age, asymptote, rate, shape):
    return asymptote * (1.0 - np.exp(-rate * age)) ** shape


def _value(field: dict | None):
    return None if field is None else field.get("value")


@lru_cache(maxsize=None)
def fit_species(key: str) -> dict:
    """Fit height and dbh curves to the published growth-by-age rows."""
    sp = load_json("species")["species"][key]
    rows = sp["growth_by_age"]["rows"]
    fits = {}
    for col in ("height_m", "dbh_cm"):
        pts = [(r["age_years"], r[col]) for r in rows if r.get(col) is not None]
        if len(pts) < 3:
            raise ValueError(f"{sp['name']}: need at least 3 ages with {col}, have {len(pts)}")
        age, y = (np.array(v, dtype=float) for v in zip(*pts))
        p0 = (y.max() * 1.3, 0.15, 1.2)
        params, _ = curve_fit(chapman_richards, age, y, p0=p0, bounds=([y.max() * 0.8, 0.005, 0.3], [y.max() * 5, 2.0, 5.0]), maxfev=20000)
        rmse = float(np.sqrt(np.mean((chapman_richards(age, *params) - y) ** 2)))
        fits[col] = {"params": [float(p) for p in params], "rmse": rmse, "mean": float(y.mean())}
    return fits


def _stock_co2_t_per_tree(dbh_cm, height_m, rho, a, b, r, cf):
    agb_kg = a * (rho * dbh_cm**2 * height_m) ** b
    return agb_kg * (1.0 + r) * cf * 44.0 / 12.0 / 1000.0


def _curve_stock(sp: dict, eq: dict, cf: float, key: str, density: float, surv: float, ages: np.ndarray, rng) -> np.ndarray:
    fits = fit_species(key)
    hp, dp = fits["height_m"], fits["dbh_cm"]
    # Spread growth by each curve's fit error, survival by 10 points, the equation coefficient by 10%.
    h_scale = 1 + rng.normal(0, hp["rmse"] / hp["mean"], DRAWS)
    d_scale = 1 + rng.normal(0, dp["rmse"] / dp["mean"], DRAWS)
    s_draw = np.clip(surv + rng.uniform(-0.10, 0.10, DRAWS), 0.05, 1.0)
    a_draw = eq["a"] * (1 + rng.normal(0, 0.10, DRAWS))
    h = np.outer(h_scale, chapman_richards(ages, *hp["params"]))
    d = np.outer(d_scale, chapman_richards(ages, *dp["params"]))
    rho, r = _value(sp["wood_density_g_cm3"]), _value(sp["root_to_shoot"])
    return _stock_co2_t_per_tree(d, h, rho, a_draw[:, None], eq["b"], r, cf) * density * s_draw[:, None]


def _rate_stock(sp: dict, ages: np.ndarray, rng) -> tuple[np.ndarray, dict]:
    pub = sp["published_co2_t_per_ha_per_year"]
    low, high = pub.get("low"), pub.get("high")
    if low is None or high is None:
        raise ValueError(f"{sp['name']}: no growth curve and no published removal rate in data/species.json")
    r = _value(sp["root_to_shoot"])
    with_roots = bool(pub.get("above_ground_only")) and r is not None
    if with_roots:
        low, high = low * (1 + r), high * (1 + r)
    rate = rng.triangular(low, (low + high) / 2, high, DRAWS)
    info = {"rate_t_per_ha_year": {"low": round(low, 2), "high": round(high, 2)}, "roots_added": with_roots,
            "note": "Constant yearly rate from a published per-hectare range; growth by year is not modelled."}
    return rate[:, None] * ages[None, :], info


def estimate(species: str, area_ha: float, years: int = 10, planting_density: float | None = None,
             survival: float | None = None, buffer: float = 0.15, baseline_t_per_ha_year: float = 0.0,
             leakage_t_per_ha_year: float = 0.0) -> dict:
    if not 0.15 <= buffer <= 0.20:
        raise ValueError("buffer must be between 0.15 and 0.20")
    data = load_json("species")
    sp = data["species"][species]
    eq = data["biomass_equation"]
    cf = _value(data["carbon_fraction"])
    density = planting_density or _value(sp["planting_density_per_ha"])
    surv = survival if survival is not None else _value(sp["survival"])
    harvest = _value(sp["harvest_age_years"])
    horizon = max(years, int(harvest or 0))
    ages = np.arange(0, horizon + 1, dtype=float)
    rng = np.random.default_rng(SEED)

    method, extra = "growth_curve", {}
    try:
        if density is None or surv is None:
            raise ValueError("planting density or survival unknown")
        stock_ha = _curve_stock(sp, eq, cf, species, density, surv, ages, rng)
        extra = {"planting_density_per_ha": density, "survival": surv,
                 "fit_rmse": {k: v["rmse"] for k, v in fit_species(species).items()}}
    except ValueError as curve_problem:
        method = "published_rate"
        stock_ha, extra = _rate_stock(sp, ages, rng)
        extra["why_not_growth_curve"] = str(curve_problem)

    if harvest:
        cap = stock_ha[:, 1:int(harvest) + 1].mean(axis=1, keepdims=True)
        stock_ha = np.minimum(stock_ha, cap)

    gross = np.diff(stock_ha[:, : years + 1], axis=1)
    net = np.clip(gross - baseline_t_per_ha_year - leakage_t_per_ha_year, 0, None) * (1 - buffer) * area_ha

    def band(x):
        lo, mid, hi = np.percentile(x, [10, 50, 90])
        return {"low": round(float(lo), 2), "likely": round(float(mid), 2), "high": round(float(hi), 2)}

    return {
        "species": sp["name"],
        "area_ha": area_ha,
        "method": method,
        "per_year": [{"year": i + 1, "co2_t": band(net[:, i])} for i in range(years)],
        "total_co2_t": band(net.sum(axis=1)),
        "average_per_year_co2_t": band(net.mean(axis=1)),
        "assumptions": {
            "buffer": buffer, "baseline_t_per_ha_year": baseline_t_per_ha_year,
            "leakage_t_per_ha_year": leakage_t_per_ha_year, "harvest_age_years": harvest,
            "capped_at_long_term_average": bool(harvest), "draws": DRAWS, "verified": False, **extra,
        },
        "demo": True,
    }
