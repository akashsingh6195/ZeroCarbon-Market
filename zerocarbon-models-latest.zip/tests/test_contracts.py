import json

import pytest
from jsonschema import Draft202012Validator

from zerocarbon_models import contracts

EXPECTED = [
    "claim_check",
    "comply_forecast",
    "listing",
    "need_result",
    "ranked_listings",
    "record_fields",
    "scan_result",
    "score_result",
]


def test_names_cover_every_contract():
    assert contracts.names() == EXPECTED


def test_version_file():
    assert (contracts.CONTRACTS_DIR / "VERSION").read_text(encoding="utf-8") == "1.0"


@pytest.mark.parametrize("name", EXPECTED)
def test_schema_is_valid_draft_2020_12(name):
    Draft202012Validator.check_schema(contracts.schema(name))


@pytest.mark.parametrize("name", EXPECTED)
def test_example_validates(name):
    contracts.validate(name, contracts.example(name))


@pytest.mark.parametrize("name", EXPECTED)
def test_missing_demo_fails(name):
    obj = contracts.example(name)
    del obj["demo"]
    with pytest.raises(ValueError, match=rf"^{name}: .*demo"):
        contracts.validate(name, obj)


@pytest.mark.parametrize("name", EXPECTED)
def test_demo_false_fails(name):
    obj = contracts.example(name)
    obj["demo"] = False
    with pytest.raises(ValueError, match=rf"^{name}: "):
        contracts.validate(name, obj)


@pytest.mark.parametrize("name", EXPECTED)
def test_unknown_field_fails(name):
    obj = contracts.example(name)
    obj["surprise"] = 1
    with pytest.raises(ValueError, match=rf"^{name}: "):
        contracts.validate(name, obj)


def test_unknown_market_in_listing_fails():
    listing = contracts.example("listing")
    listing["market"] = "moon_market"
    with pytest.raises(ValueError, match=r"^listing: market: "):
        contracts.validate("listing", listing)


def test_not_eligible_scan_with_null_ranges_validates():
    scan = contracts.example("scan_result")
    scan.update(
        verdict="not_eligible",
        reasons=["Already under dense trees"],
        method=None,
        species=[],
        credits_per_year=None,
        money_inr=None,
    )
    contracts.validate("scan_result", scan)


def test_not_eligible_scan_with_credits_fails():
    scan = contracts.example("scan_result")
    scan["verdict"] = "not_eligible"
    with pytest.raises(ValueError, match=r"^scan_result: "):
        contracts.validate("scan_result", scan)


def test_scan_reasons_at_most_three():
    scan = contracts.example("scan_result")
    scan["reasons"] = ["a", "b", "c", "d"]
    with pytest.raises(ValueError, match=r"^scan_result: reasons: "):
        contracts.validate("scan_result", scan)


def test_filters_accept_null_and_empty():
    need = contracts.example("need_result")
    need["filters"] = {k: None for k in need["filters"]}
    contracts.validate("need_result", need)
    need["filters"].update(market=[], action=[], status=[])
    contracts.validate("need_result", need)


def test_unknown_flag_code_fails():
    score = contracts.example("score_result")
    score["flags"][0]["code"] = "looks_odd"
    with pytest.raises(ValueError, match=r"^score_result: flags\.0\.code: "):
        contracts.validate("score_result", score)


def test_example_is_a_fresh_copy():
    a = contracts.example("listing")
    a["id"] = "changed"
    assert contracts.example("listing")["id"] == "L-0007"


def test_unknown_contract_name():
    with pytest.raises(ValueError, match=r"^nope: unknown contract"):
        contracts.validate("nope", {})


def test_every_object_closed_and_every_field_described():
    def walk(node, where):
        if isinstance(node, dict):
            if "properties" in node:
                assert node.get("additionalProperties") is False, where
                for key, sub in node["properties"].items():
                    assert sub.get("description"), f"{where}.{key}"
            for key, sub in node.items():
                if key in ("if", "then", "else"):  # conditions, not data objects
                    continue
                walk(sub, f"{where}/{key}")
        elif isinstance(node, list):
            for i, sub in enumerate(node):
                walk(sub, f"{where}/{i}")

    for name in EXPECTED:
        s = contracts.schema(name)
        assert s["properties"]["demo"]["const"] is True
        assert "demo" in s["required"]
        walk(s, name)


def test_examples_files_are_plain_json():
    for name in EXPECTED:
        path = contracts.EXAMPLES_DIR / f"{name}.json"
        assert json.loads(path.read_text(encoding="utf-8")) == contracts.example(name)
