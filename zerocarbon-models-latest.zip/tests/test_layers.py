import math

import pytest

from zerocarbon_models.layers import area_ha, land_summary, metres_per_degree, square_plot

TOP_KEYS = {
    "area_ha", "worldcover", "trees_by_year", "crops_by_year",
    "water_occurrence_pct", "elevation_m", "slope_deg", "errors", "timings_s",
}
WORLDCOVER_KEYS = {
    "trees", "shrub", "grass", "cropland", "built", "bare",
    "water", "wetland", "mangrove", "other",
}


def test_one_hectare_square_offline():
    lat, lon = 12.5489, 76.8786  # fields near Mandya
    sq = square_plot(lat, lon)
    ring = sq["coordinates"][0]
    assert sq["type"] == "Polygon" and ring[0] == ring[-1] and len(ring) == 5

    # Centred on the point, 100 m a side.
    xs = [p[0] for p in ring]
    ys = [p[1] for p in ring]
    assert math.isclose((min(xs) + max(xs)) / 2, lon, abs_tol=1e-12)
    assert math.isclose((min(ys) + max(ys)) / 2, lat, abs_tol=1e-12)
    m_lat, m_lon = metres_per_degree(lat)
    assert math.isclose((max(xs) - min(xs)) * m_lon, 100.0, rel_tol=1e-9)
    assert math.isclose((max(ys) - min(ys)) * m_lat, 100.0, rel_tol=1e-9)

    # Equal-area measurement gives 1 ha, here and far from the equator.
    assert area_ha(sq) == pytest.approx(1.0, abs=0.002)
    assert area_ha(square_plot(60.0, 10.0)) == pytest.approx(1.0, abs=0.002)
    assert area_ha(square_plot(lat, lon, side_m=200.0)) == pytest.approx(4.0, abs=0.01)

    # One degree of latitude is about 110.6 km at 12.5 N.
    assert m_lat == pytest.approx(110_630, rel=1e-3)


@pytest.mark.network
def test_land_summary_keys_live():
    r = land_summary(12.5489, 76.8786)  # irrigated fields near Mandya
    assert set(r) == TOP_KEYS
    assert r["area_ha"] == pytest.approx(1.0, abs=0.002)
    assert set(r["errors"]) <= {"worldcover", "io_lulc", "water", "dem"}
    assert {"worldcover", "io_lulc", "water", "dem", "total"} <= set(r["timings_s"])
    if r["worldcover"] is not None:
        assert set(r["worldcover"]) == WORLDCOVER_KEYS
        assert sum(r["worldcover"].values()) == pytest.approx(1.0, abs=0.01)
    if r["trees_by_year"] is not None:
        assert "2017" in r["trees_by_year"] and set(r["trees_by_year"]) == set(r["crops_by_year"])
    if r["water_occurrence_pct"] is not None:
        assert 0.0 <= r["water_occurrence_pct"] <= 100.0
    if r["slope_deg"] is not None:
        assert 0.0 <= r["slope_deg"] < 90.0
