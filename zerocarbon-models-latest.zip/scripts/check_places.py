"""Run scan_land on the known places in eval/places_raw.json and write eval/places_report.md."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from zerocarbon_models.contracts import validate  # noqa: E402
from zerocarbon_models.scan import scan_land  # noqa: E402

EXPECTED = {
    "forest": {"not_eligible", "needs_checks"},
    "water": {"not_eligible"},
    "town": {"not_eligible"},
    "farmland": {"likely_eligible"},
}


def main() -> None:
    raw = json.loads((ROOT / "eval" / "places_raw.json").read_text(encoding="utf-8"))
    places = raw["places"] if isinstance(raw, dict) else raw
    rows, right, slowest = [], 0, 0.0
    for p in places:
        kind = p.get("expected_type", p.get("type", "")).lower()
        start = time.perf_counter()
        out = scan_land(p["lat"], p["lon"])
        took = time.perf_counter() - start
        slowest = max(slowest, took)
        validate("scan_result", out)
        ok = out["verdict"] in EXPECTED.get(kind, set())
        right += ok
        credits = out["credits_per_year"]
        rows.append(f"| {p['name']} | {kind} | {out['verdict']} | {'yes' if ok else 'NO'} | "
                    f"{credits['likely'] if credits else '-'} | {'; '.join(out['reasons'])} | {took:.1f} s |")
    report = [
        "# ZeroCarbon Scan: check on known places",
        "",
        f"{right} of {len(places)} verdicts as expected. Slowest scan: {slowest:.1f} s.",
        "",
        "| Place | Type | Verdict | As expected | Likely tCO2e/yr (1 ha) | Reasons | Time |",
        "| --- | --- | --- | --- | --- | --- | --- |",
        *rows,
        "",
        "Expected: forest is not eligible or needs checks; water and town are not eligible; farmland is likely eligible.",
    ]
    (ROOT / "eval" / "places_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print("\n".join(report))


if __name__ == "__main__":
    main()
