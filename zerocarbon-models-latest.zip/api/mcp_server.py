"""MCP server: the same models and tools, for AgenticOrg's Remote MCP connector `zerocarbon_models`."""
from __future__ import annotations

from typing import Any

from mcp.server.mcpserver import MCPServer
from mcp.server.transport_security import TransportSecuritySettings
from mcp.types import ToolAnnotations

from zerocarbon_models import comply, scan, score, tools
from zerocarbon_models.contracts import validate

mcp = MCPServer(
    name="zerocarbon_models",
    instructions="Numbers for ZeroCarbon Market: land scans, scores, compliance forecasts, prices and lookups. Every answer is demo data.",
)

# Every tool only reads; AgenticOrg lets agents call a remote tool without approval only when it says so.
READ_ONLY = ToolAnnotations(readOnlyHint=True, destructiveHint=False, idempotentHint=True)


@mcp.tool(structured_output=True, annotations=READ_ONLY, description="Check a plot of land in Karnataka: can it earn carbon credits, by which method, and roughly how many tonnes and rupees a year.")
def scan_land(lat: float, lon: float, boundary_geojson: dict | None = None) -> dict[str, Any]:
    out = scan.scan_land(lat, lon, boundary_geojson)
    validate("scan_result", out)
    return out


@mcp.tool(structured_output=True, annotations=READ_ONLY, description="ZeroCarbon Score (0-100) and integrity flags for one listing.")
def score_listing(listing_id: str, status: str = "issued", boundary_geojson: dict | None = None, serials: str | None = None,
                  issued_on: str | None = None, species: str | None = None, documents: list[str] | None = None,
                  delivery_year: int | None = None, long_term_average_cap: bool = False) -> dict[str, Any]:
    out = score.score_listing(listing_id, status, boundary_geojson, serials, issued_on, species, documents, delivery_year, long_term_average_cap)
    validate("score_result", out)
    return out


@mcp.tool(structured_output=True, annotations=READ_ONLY, description="Forecast an obligated plant's year-end emissions per tonne against its CCTS target, and the shortfall in tonnes. months: [{month, production_t, coal_t, gas_scm, power_kwh, diesel_l}].")
def comply_forecast(plant_id: str, target: float, months: list[dict], expected_yearly_production_t: float | None = None) -> dict[str, Any]:
    out = comply.comply_forecast(plant_id, target, months, expected_yearly_production_t)
    validate("comply_forecast", out)
    return out


@mcp.tool(structured_output=True, annotations=READ_ONLY, description="Demo monthly prices for voluntary credits by method (removal, reduction, avoidance) and vintage.")
def price_series(method: str | None = None, vintage: int | None = None) -> dict[str, Any]:
    return tools.price_series(method, vintage)


@mcp.tool(structured_output=True, annotations=READ_ONLY, description="Listings that match a buyer's filters. buyer_type: voluntary, obligated or trader (traders only ever get voluntary credits).")
def search_listings(filters: dict | None = None, buyer_type: str = "voluntary") -> dict[str, Any]:
    return tools.search_listings(filters, buyer_type)


@mcp.tool(structured_output=True, annotations=READ_ONLY, description="The rules for honest claims about retired credits, and the safe sentence template.")
def claim_rules() -> dict[str, Any]:
    return tools.claim_rules()


@mcp.tool(structured_output=True, annotations=READ_ONLY, description="Words and claim phrases that must never reach a user.")
def banned_words() -> dict[str, Any]:
    return tools.banned_words()


@mcp.tool(structured_output=True, annotations=READ_ONLY, description="Plain-English passages about carbon credits and ZeroCarbon Market that answer a question.")
def knowledge_lookup(question: str) -> dict[str, Any]:
    return tools.knowledge_lookup(question)


@mcp.tool(structured_output=True, annotations=READ_ONLY, description="Fees, time to first money and paperwork for each route (ZeroCarbon Pool, Indian offset project, voluntary standard).")
def route_costs(area_ha: float, credits_per_year_likely: float) -> dict[str, Any]:
    return tools.route_costs(area_ha, credits_per_year_likely)


mcp_app = mcp.streamable_http_app(
    streamable_http_path="/mcp",
    stateless_http=True,
    json_response=True,
    host="0.0.0.0",
    transport_security=TransportSecuritySettings(enable_dns_rebinding_protection=False),
)
