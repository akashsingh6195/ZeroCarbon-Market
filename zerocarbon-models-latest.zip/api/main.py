"""REST API for the Replit website, with the MCP server mounted at /mcp on the same app."""
from __future__ import annotations

import secrets
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from api.mcp_server import mcp, mcp_app
from zerocarbon_models import comply, scan, score, tools
from zerocarbon_models.config import ROOT, env
from zerocarbon_models.contracts import validate


@asynccontextmanager
async def lifespan(_app: FastAPI):
    async with mcp.session_manager.run():
        yield


app = FastAPI(title="zerocarbon-models", lifespan=lifespan)


def given_keys(request: Request) -> list[str]:
    # Clients differ in where they put the key: X-API-Key, Api-Key, or Authorization with or without a scheme.
    keys = [request.headers.get(h, "") for h in ("x-api-key", "api-key")]
    auth = request.headers.get("authorization", "").strip()
    scheme, _, rest = auth.partition(" ")
    keys.append(rest.strip() if scheme.lower() in ("bearer", "apikey", "api-key", "token") else auth)
    return [k for k in keys if k]


@app.middleware("http")
async def check_key(request: Request, call_next):
    path = request.url.path
    if path in ("/", "/health"):
        return await call_next(request)
    expected = env("MCP_KEY") if path.startswith("/mcp") else env("MODELS_API_KEY")
    ok = bool(expected) and any(secrets.compare_digest(k.encode(), expected.encode()) for k in given_keys(request))
    if not ok:
        return JSONResponse({"error": "missing or wrong API key"}, status_code=401)
    return await call_next(request)


def checked(name: str, obj: dict) -> dict:
    try:
        validate(name, obj)
    except ValueError as e:
        raise HTTPException(status_code=500, detail=str(e)) from e
    return obj


class ScanIn(BaseModel):
    lat: float
    lon: float
    boundary_geojson: dict | None = None


class ScoreIn(BaseModel):
    listing_id: str
    status: str = "issued"
    boundary_geojson: dict | None = None
    serials: str | None = None
    issued_on: str | None = None
    species: str | None = None
    documents: list[str] = []
    delivery_year: int | None = None
    long_term_average_cap: bool = False
    tree_cover_by_year: dict | None = None


class ComplyIn(BaseModel):
    plant_id: str
    target: float
    months: list[dict]
    expected_yearly_production_t: float | None = None


@app.get("/")
async def root() -> dict:
    # Hosting platforms check that "/" answers before they go live; it carries no data.
    # Both checks are async so they answer even while slow satellite reads hold the worker threads.
    return {"ok": True, "service": "zerocarbon-models"}


@app.get("/health")
async def health() -> dict:
    return {"ok": True, "contracts_version": (ROOT / "contracts" / "VERSION").read_text().strip()}


@app.post("/scan")
def post_scan(body: ScanIn) -> dict:
    return checked("scan_result", scan.scan_land(body.lat, body.lon, body.boundary_geojson))


@app.post("/score")
def post_score(body: ScoreIn) -> dict:
    return checked("score_result", score.score_listing(**body.model_dump()))


@app.post("/comply/forecast")
def post_comply(body: ComplyIn) -> dict:
    try:
        out = comply.comply_forecast(body.plant_id, body.target, body.months, body.expected_yearly_production_t)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e)) from e
    return checked("comply_forecast", out)


@app.get("/prices")
def get_prices(method: str | None = None, vintage: int | None = None) -> dict:
    return tools.price_series(method, vintage)


class RoutesIn(BaseModel):
    area_ha: float = Field(gt=0)
    credits_per_year_likely: float = Field(ge=0)


@app.post("/routes")
def post_routes(body: RoutesIn) -> dict:
    return tools.route_costs(body.area_ha, body.credits_per_year_likely)


# Mounted last so the REST routes above match first; the MCP app serves /mcp.
app.mount("/", mcp_app)
