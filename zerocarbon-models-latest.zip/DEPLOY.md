# Host zerocarbon-models on Replit

About 15 minutes. You need the three keys from your local `.env` file (`D:\ZeroCarbon\zerocarbon-models\.env`).

1. **Import:** on replit.com, Create App, then Import from GitHub, and pick `zerocarbon-models`. If Replit asks, connect your GitHub account and allow it to read this private repo.
2. **Secrets** (Secrets tool):

| Secret | Value |
| --- | --- |
| `MODELS_API_KEY` | from your local `.env` |
| `MCP_KEY` | from your local `.env` |
| `INTERNAL_KEY` | from your local `.env`; the website must have the same value |
| `REPLIT_LISTINGS_URL` | `https://zero-carbon-market.replit.app/api/internal/listings` |

3. **Install and run:** the `.replit` file adds the `expat` system package that the map library needs.
   Then in the Shell tab run `pip install -r requirements.txt`, then press Run. Open the preview and add `/health` to the address: it should show `{"ok": true, "contracts_version": "1.0"}`.
4. **Publish:** open Publishing, choose **Reserved VM** (it never sleeps, so the first scan isn't slow), check the secrets are copied into the deployment, and publish. Note the address it gives, for example `https://zerocarbon-models.<you>.replit.app`.
5. **Connect the website:** in the `zero-carbon-market` app's Secrets set `MODELS_API_URL` to that address (no trailing slash) and `MODELS_API_KEY` to the same key as step 2, then republish the website.
6. **Connect AgenticOrg:** Connectors, then Remote MCP, then Add. Name `zerocarbon_models`, address `<that address>/mcp`, header `X-API-Key` = your `MCP_KEY`. Call each tool once from a test agent.
7. **Check:**
   - `<address>/health` answers without a key.
   - The website's Scan page gives a land card for a field near Mandya (12.5489, 76.8786) instead of "Scan is busy".
   - In AgenticOrg, `search_listings` returns the website's live listings. If it returns nothing, the website's listing fields may be named differently from `contracts/listing.schema.json`; compare one listing with that file.
