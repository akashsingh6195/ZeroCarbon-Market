## Carbon credit
A carbon credit is a record that one tonne of carbon dioxide was kept out of the air or taken out of it. A project, such as a tree plantation or a cleaner cooking stove scheme, is checked by an outside auditor before any credit is made. A registry then gives each credit its own serial number so it can be tracked and used only once.

## Tonne of CO2
One tonne of CO2 is the unit every carbon credit counts in. Other warming gases, such as methane, are turned into the amount of CO2 that would warm the planet the same, which is why you will see "tCO2e" (tonnes of CO2 equivalent).

## Removal, reduction and avoidance
These are the three kinds of credit. Removal credits come from taking CO2 out of the air, for example trees that store carbon as they grow. Reduction credits come from cutting emissions that were already happening, such as a factory using less fuel, and avoidance credits come from stopping emissions that would otherwise have happened, such as protecting a forest from being cleared. Only removal credits can be described as removing CO2.

## Vintage
The vintage is the year the CO2 was actually removed, reduced or avoided. A 2025 vintage credit is for work done in 2025, even if it was issued or sold later. Buyers often prefer recent vintages.

## Registry
A registry is the official record book for credits. It issues each credit with a serial number, tracks who holds it, and marks it as used when it is retired. For India's scheme the registry is GRID-INDIA; for voluntary credits it is the standard's own registry, such as Verra or Gold Standard.

## Retirement
Retiring a credit means using it up for good. The registry marks its serial number as retired, so it can never be sold or claimed again. Only retired credits can back any claim a company makes about its emissions.

## Future and issued credits
Issued credits already exist in a registry, with serial numbers. Future credits are credits a project expects to make later, for example once newly planted trees have grown and been checked; they come with a delivery year. A buyer of future credits cannot claim them until they are issued and retired.

## Obligated entity
An obligated entity is a plant that India's Carbon Credit Trading Scheme gives a target for cutting its emissions per unit of product. About 490 plants in 7 sectors have targets for 2025-26 and 2026-27. A plant that beats its target earns certificates; one that misses it must buy certificates to cover the gap.

## Non-obligated entity
A non-obligated entity is any company without a target under India's scheme. It can take part in the offset market, for example by registering a project that cuts or removes emissions and earning certificates for it. Only Indian firms can register offset projects.

## CCTS (India's Carbon Credit Trading Scheme)
CCTS is India's own carbon market, set up under the Energy Conservation Act after it was changed in 2022. The Bureau of Energy Efficiency (BEE) runs it and GRID-INDIA keeps the registry. It has two parts: a compliance market and an offset market.

## Compliance market and offset market
In the compliance market, plants with targets (obligated entities) earn or buy certificates depending on whether they beat or miss their targets. In the offset market, companies without targets (non-obligated entities) earn certificates from projects. An offset project goes through 7 steps: register an account, write a project design document, have it checked (validated) by an accredited auditor, get the project registered, monitor it, have the results checked (verified) by a different auditor, and then receive the certificates.

## The monthly exchange session
India's carbon certificates can be traded only on power exchanges regulated by the Central Electricity Regulatory Commission (CERC). Trading happens in one session a month. CERC notified its rules for this on 27 February 2026, which is why ZeroCarbon does not trade these certificates itself.

## Green Credits are not carbon credits
Green Credits come from a separate government programme run by the environment ministry that rewards actions such as planting trees or saving water. They are not counted in tonnes of CO2 and are not carbon credits. They cannot be used to back a claim about a company's emissions.

## Renewable Energy Certificates
A Renewable Energy Certificate (REC) stands for one megawatt-hour of electricity made from a renewable source such as sun or wind. Companies use them to show they met a duty to buy a share of renewable power. A REC counts electricity, not tonnes of CO2, so it is not a carbon credit.

## Energy Saving Certificates
Energy Saving Certificates (ESCerts) are given out under India's Perform, Achieve and Trade (PAT) scheme for large energy-using plants. A plant that saves more energy than its target earns them, and a plant that falls short has to buy them. They count energy saved, not tonnes of CO2, so they are not carbon credits.

## Buffer
A buffer is a share of a project's credits that is held back and never sold; ZeroCarbon holds back 15 to 20%. It covers losses such as a fire, a drought or trees being cut early. If a project loses carbon it had already been credited for, credits are cancelled from the buffer instead of from buyers.

## ZeroCarbon Score
The ZeroCarbon Score is a number from 0 to 100 that shows how much care a listing needs. It starts at 100 and loses points for each warning sign found, such as the land overlapping another project, the same credits listed twice, trees lost after credits were issued, trees cut for timber without the credits being capped, missing documents, or future credits with no delivery year. A lower score means check more before you buy, not that the credits are fake.

## ZeroCarbon Pool
The ZeroCarbon Pool is ZeroCarbon's own project that joins many small plots into one project design document. India's rules allow several plots to be bundled this way, and the bundle pays one set of fees, so each landowner pays far less than going alone. The fee split is still being worked out.

## ZeroCarbon Scan
ZeroCarbon Scan looks at a piece of land from satellite images and tells you whether it is likely to qualify for tree-planting credits. It shows what the land is used for now, which trees might suit it, and a low, likely and high range of credits and money a year. It also lists what it cannot see from space, such as who owns the land or any loans on it.

## Why traders deal in voluntary credits only
India's own carbon certificates can be traded only on CERC-regulated power exchanges, so a private marketplace cannot buy and sell them. On ZeroCarbon, traders may buy and sell voluntary credits only, which are issued by standards such as Verra and Gold Standard. Obligated plants that need India's certificates are pointed to the exchange session.

## How to buy
Tell ZeroCarbon what you need in your own words, for example the number of tonnes, the kind of credit and your budget. Pick a listing, check its ZeroCarbon Score and documents, and pay. The credits are retired in your name and you get the registry record with serial numbers, plus wording you can safely use about what you did.

## How to list credits
Create a seller account and add your project. For issued credits, upload the registry statement with serial numbers, the verification report, the project design document and proof that you own the land or project. For future credits, upload the design document or registration proof, the planting plan, ownership proof and a delivery schedule. ZeroCarbon checks the listing and gives it a score before it goes live.

## Is buying credits an investment?
No. ZeroCarbon does not offer investments, and credits bought here are for retiring against your own emissions. We never promise that a credit will gain value, and nothing on ZeroCarbon should be read as advice about money.

## Does buying make my company zero carbon?
No. ZeroCarbon is the name of the marketplace, not something a buyer becomes. Retiring credits lets you say exactly what you did, for example "We retired 500 tonnes of removal credits from a named project, vintage 2025". A wider claim such as carbon neutral or net zero needs retired tonnes at least equal to all your emissions for the same period, backed by evidence, as India's 2024 greenwashing guidelines expect.
