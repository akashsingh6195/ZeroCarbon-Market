# zerocarbon-models

The service behind ZeroCarbon Market's numbers. One app serves two callers:

- **REST** for the Replit website: land scans, scores, compliance forecasts, prices.
- **MCP** at `/mcp` for AgenticOrg's Remote MCP connector `zerocarbon_models`: the same models plus the lookup tools the agents use.

Every answer carries `"demo": true`. Numbers come from tested code, never from a language model.

## Run it

```
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
copy .env.example .env      (then fill in the three keys)
.venv\Scripts\python -m uvicorn api.main:app --port 8000
```

Tests: `.venv\Scripts\python -m pytest -q` (add `-m "not network"` to skip the live satellite test).

Check the scan on known places: `.venv\Scripts\python scripts\check_places.py` (writes `eval/places_report.md`).

## For Replit

Send the header `X-API-Key: <MODELS_API_KEY>` on every call except `/health`.

| Call | Body | Returns |
| --- | --- | --- |
| `GET /health` | none | `{"ok": true, "contracts_version": "1.0"}` |
| `POST /scan` | `{"lat": 13.43, "lon": 77.73, "boundary_geojson": null}` | ScanResult |
| `POST /score` | `{"listing_id": "L-1", "status": "future", "documents": [], "delivery_year": null}` | ScoreResult |
| `POST /comply/forecast` | `{"plant_id": "P-1", "target": 0.68, "months": [{"month": "2026-04", "production_t": 100000, "coal_t": 9000, "power_kwh": 9000000}]}` | ComplyForecast |
| `GET /prices?method=removal&vintage=2025` | none | demo price series |

Example:

```
curl -X POST http://localhost:8000/scan -H "X-API-Key: <MODELS_API_KEY>" -H "Content-Type: application/json" -d "{\"lat\": 13.43, \"lon\": 77.73}"
```

The shapes are in `contracts/` (JSON Schema); copy them into the website's `shared/contracts/`.

## For AgenticOrg

1. Connectors, then Remote MCP, then Add.
2. Name `zerocarbon_models`; address `https://<host>/mcp`; header `X-API-Key: <MCP_KEY>`.
3. Tools: `scan_land`, `score_listing`, `comply_forecast`, `price_series`, `search_listings`, `claim_rules`, `banned_words`, `knowledge_lookup`, `route_costs`.
4. Test each tool once from a throwaway agent and check the arguments arrive.

## Data files and what is still unverified

| File | What it holds |
| --- | --- |
| `data/species.json`, `data/SOURCES_species.md` | Tree data for Melia dubia and teak, every value with its source; `verified: false` until checked |
| `data/fees.json` | BEE offset fee schedule (verified from the BEE procedure); voluntary-standard fees and timings are placeholders |
| `data/prices.json` | Demo prices only |
| `data/emission_factors.json` | Fuel and grid factors with sources; `verified: false` |
| `data/scan_rules.json` | Scan thresholds; the BM FR05.002 land-history years are a placeholder |
| `data/claim_rules.json`, `data/banned_words.json`, `data/knowledge.md` | Agent rules and plain-English help |
| `data/demo_listings.json` | Fictional listings used when `REPLIT_LISTINGS_URL` is empty |

## Where it stands

- Tests: 72 pass. Live check on 8 known places: 7 of 8 as expected, scans take 2 to 4 s (`eval/places_report.md`). The miss is a Chikkaballapur field the satellite map shows as half trees; the scan sends it for checks rather than approving it.
- The scan reads land cover (ESA WorldCover 2021), yearly land cover (Impact Observatory 2017 onward) and water history (JRC) on demand from Microsoft Planetary Computer, with no account. Elevation is skipped: its reads take 5 to 20 s.
- Growth: Melia dubia uses a published per-hectare removal rate (South Indian woodlots), with roots added and a cap at the long-term average because it is harvested at about 9 years. The tree-by-tree growth curves switch on once at least 3 ages, planting density and survival are in `data/species.json`.

## Known limits

- Not online yet: hosting needs a GitHub push and a Replit deployment, on your word.
- Karnataka is a rough box, not the state boundary. No rainfall check for species yet.
- The yearly tree layer flips between trees and rangeland in dry forests, so tree history only ever sends a plot for checks.
- The teak removal rate in `data/species.json` may be too high (see `data/SOURCES_species.md`).
- The grid emission factor is CEA's provisional FY 2024-25 figure; the newer CEA version 22.0 should replace it.
- The full 40-plot accuracy check is not done.
