"""Lookup tools the agents call: words, claim rules, route costs, knowledge, listings, prices."""
from __future__ import annotations

import re
from datetime import date

import httpx
import numpy as np
from rank_bm25 import BM25Okapi

from .config import env, load_json, load_text

ROUTES = ("zerocarbon_pool", "india_offset", "voluntary")


def banned_words() -> dict:
    data = load_json("banned_words")
    return {**data, "demo": True}


def claim_rules() -> dict:
    data = load_json("claim_rules")
    return {**data, "demo": True}


def _registration_fee(fees: dict, credits_per_year: float) -> int:
    for tier in fees["project_registration_inr"]:
        if tier["max_t_per_year"] is None or credits_per_year <= tier["max_t_per_year"]:
            return tier["fee_inr"]
    return fees["project_registration_inr"][-1]["fee_inr"]


def route_costs(area_ha: float, credits_per_year_likely: float) -> dict:
    """Fees, time to first money and whether fixed costs swamp the money, per route."""
    fees = load_json("fees")
    prices = load_json("prices")
    months = fees.get("first_money_months", {})
    landowner_price = prices["landowner_price_inr_per_t"]
    credits = max(float(credits_per_year_likely), 0.0)
    money_likely = round(credits * landowner_price["likely"])

    off = fees["india_offset"]
    offset_first = (
        off["account_registration_inr"]
        + off["account_maintenance_inr_per_year"]
        + _registration_fee(off, credits)
        + off["issuance_inr_per_credit"] * credits
    )
    offset_yearly = off["account_maintenance_inr_per_year"] + off["issuance_inr_per_credit"] * credits

    vol = fees.get("voluntary", {})
    vol_reg, vol_iss = vol.get("registration_inr"), vol.get("issuance_inr_per_credit")
    vol_first = None if vol_reg is None or vol_iss is None else round(vol_reg + vol_iss * credits)
    vol_yearly = None if vol_iss is None else round(vol_iss * credits)

    def band(name: str) -> dict:
        m = months.get(name) or {}
        return {"low": m.get("low"), "high": m.get("high")}

    routes = [
        {
            "route": "zerocarbon_pool",
            "fees_inr_first_year": 0,
            "fees_inr_yearly": 0,
            "first_money_months": band("zerocarbon_pool"),
            "paperwork": "ZeroCarbon's registered firm files one bundled project for many plots; you sign one agreement.",
            "fixed_costs_exceed_likely_money": False,
            "notes": ["Fees are shared across the pool; the operator's share is still to be agreed (unverified)."],
        },
        {
            "route": "india_offset",
            "fees_inr_first_year": round(offset_first),
            "fees_inr_yearly": round(offset_yearly),
            "first_money_months": band("india_offset"),
            "paperwork": "An Indian firm registers on the ICM portal, writes a design document, and pays two accredited verifiers.",
            "fixed_costs_exceed_likely_money": offset_first > money_likely,
            "notes": ["Only Indian firms can register offset projects.", "Verifier fees are not included."],
        },
        {
            "route": "voluntary",
            "fees_inr_first_year": vol_first,
            "fees_inr_yearly": vol_yearly,
            "first_money_months": band("voluntary"),
            "paperwork": "A developer registers with an international standard such as Verra or Gold Standard.",
            "fixed_costs_exceed_likely_money": None if vol_first is None else vol_first > money_likely,
            "notes": ["Standard fees are placeholders until checked (unverified)."],
        },
    ]
    return {
        "area_ha": area_ha,
        "credits_per_year_likely": credits,
        "money_likely_inr_per_year": money_likely,
        "routes": routes,
        "source": off.get("source"),
        "demo": True,
    }


def _knowledge_passages() -> list[dict]:
    text = load_text("knowledge.md")
    passages = []
    for block in re.split(r"^## ", text, flags=re.M)[1:]:
        title, _, body = block.partition("\n")
        passages.append({"title": title.strip(), "text": " ".join(body.split())})
    return passages


def _tokens(s: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", s.lower())


def knowledge_lookup(question: str, k: int = 3) -> dict:
    passages = _knowledge_passages()
    if not passages:
        return {"passages": [], "demo": True}
    bm25 = BM25Okapi([_tokens(p["title"] + " " + p["text"]) for p in passages])
    scores = bm25.get_scores(_tokens(question))
    order = np.argsort(scores)[::-1][:k]
    return {"passages": [passages[i] for i in order if scores[i] > 0], "demo": True}


def _fetch_listings() -> list[dict]:
    url = env("REPLIT_LISTINGS_URL")
    if url:
        r = httpx.get(url, headers={"X-Internal-Key": env("INTERNAL_KEY", "")}, timeout=8)
        r.raise_for_status()
        data = r.json()
        return data["listings"] if isinstance(data, dict) else data
    return load_json("demo_listings")["listings"]


def search_listings(filters: dict | None = None, buyer_type: str = "voluntary") -> dict:
    """Listings matching the filters; traders see voluntary only, obligated plants compliance only."""
    f = filters or {}
    out = []
    for item in _fetch_listings():
        if item.get("hidden") or item.get("status") == "retired":
            continue
        if buyer_type == "trader" and item["market"] != "voluntary":
            continue
        if buyer_type == "obligated" and item["market"] != "india_compliance":
            continue
        if f.get("market") and item["market"] not in f["market"]:
            continue
        if f.get("action") and item["action"] not in f["action"]:
            continue
        if f.get("status") and item["status"] not in f["status"]:
            continue
        if f.get("vintage_min") and item["vintage"] < f["vintage_min"]:
            continue
        if f.get("max_price_inr") and item["price_inr_per_t"] > f["max_price_inr"]:
            continue
        if f.get("quantity_t") and item["quantity_t"] < f["quantity_t"]:
            continue
        region = f.get("region")
        if region and region.lower() not in ("india", item["region"].lower()):
            continue
        out.append(item)
    return {"listings": out, "demo": True}


def price_series(method: str | None = None, vintage: int | None = None, months: int = 12) -> dict:
    """Demo monthly prices inside the stated band; a fixed seed keeps every demo identical."""
    bands = load_json("prices")["bands_inr_per_t"]
    methods = [method] if method else ["removal", "reduction", "avoidance"]
    vintages = [vintage] if vintage else [2023, 2024, 2025]
    today = date.today()
    series = []
    for m in methods:
        band = bands.get(m)
        if band is None:
            continue
        for v in vintages:
            rng = np.random.default_rng(sum(map(ord, m)) * 10000 + v)
            mid = (band["low"] + band["high"]) / 2
            level = mid - (2025 - v) * 0.05 * mid  # older vintages sit lower in the band
            for i in range(months):
                level += rng.normal(0, 0.02 * mid)
                level = float(np.clip(level, band["low"], band["high"]))
                y, mo = divmod(today.year * 12 + today.month - 1 - (months - 1 - i), 12)
                series.append({"month": f"{y}-{mo + 1:02d}", "method": m, "vintage": v, "price_inr_per_t": round(level)})
    return {"series": series, "note": "Demo prices only, not market data.", "demo": True}
