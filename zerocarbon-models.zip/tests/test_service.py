"""Service tests: REST routes, MCP tools, and the models behind them. Satellite reads are faked here."""
import os

os.environ["MODELS_API_KEY"] = "test-models-key"
os.environ["MCP_KEY"] = "test-mcp-key"
os.environ.pop("REPLIT_LISTINGS_URL", None)

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from api.main import app  # noqa: E402
from zerocarbon_models import growth, layers, tools  # noqa: E402

H = {"X-API-Key": "test-models-key"}
MCP_H = {"X-API-Key": "test-mcp-key", "Accept": "application/json, text/event-stream", "Content-Type": "application/json"}
YEARS = [str(y) for y in range(2017, 2024)]


def summary(trees=0.03, crop=0.85, built=0.02, water=0.0, wetland=0.0, history=None, occ=0.0):
    rest = max(0.0, 1 - trees - crop - built - water - wetland)
    return {
        "area_ha": 1.0,
        "worldcover": {"trees": trees, "shrub": 0.0, "grass": rest, "cropland": crop, "built": built, "bare": 0.0,
                       "water": water, "wetland": wetland, "mangrove": 0.0, "other": 0.0},
        "trees_by_year": history or {y: trees for y in YEARS},
        "crops_by_year": {y: crop for y in YEARS},
        "water_occurrence_pct": occ, "elevation_m": 800.0, "slope_deg": 2.0, "errors": {}, "timings_s": {},
    }


PLACES = {
    "farm": summary(),
    "town": summary(trees=0.05, crop=0.0, built=0.9),
    "lake": summary(trees=0.0, crop=0.0, built=0.0, water=0.95, occ=95.0),
    "forest": summary(trees=0.9, crop=0.0, built=0.0),
    "cleared": summary(history={**{y: 0.05 for y in YEARS}, "2018": 0.7}),
}


@pytest.fixture(scope="module")
def client():
    # The MCP session manager can start only once per process, so one client serves every test.
    with TestClient(app) as c:
        yield c


def fake(monkeypatch, name):
    monkeypatch.setattr(layers, "land_summary", lambda lat, lon, boundary_geojson=None, **kw: PLACES[name])


def test_health_needs_no_key(client):
    r = client.get("/health")
    assert r.status_code == 200 and r.json()["ok"] is True


def test_rest_refuses_without_key(client):
    assert client.post("/scan", json={"lat": 13.4, "lon": 77.7}).status_code == 401
    assert client.post("/scan", json={"lat": 13.4, "lon": 77.7}, headers={"X-API-Key": "wrong"}).status_code == 401


@pytest.mark.parametrize("place,verdicts", [
    ("farm", {"likely_eligible"}),
    ("town", {"not_eligible"}),
    ("lake", {"not_eligible"}),
    ("forest", {"not_eligible"}),
    ("cleared", {"needs_checks"}),
])
def test_scan_verdicts(client, monkeypatch, place, verdicts):
    fake(monkeypatch, place)
    r = client.post("/scan", json={"lat": 13.4, "lon": 77.7}, headers=H)
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["verdict"] in verdicts
    if body["verdict"] == "not_eligible":
        assert body["credits_per_year"] is None and body["money_inr"] is None
    if place == "farm":
        c = body["credits_per_year"]
        assert 0 < c["low"] <= c["likely"] <= c["high"]


def test_scan_outside_karnataka_needs_checks(client, monkeypatch):
    fake(monkeypatch, "farm")
    body = client.post("/scan", json={"lat": 28.6, "lon": 77.2}, headers=H).json()
    assert body["verdict"] == "needs_checks" and body["reasons"][0] == "Scan covers Karnataka today"


def test_score_flags_future_without_delivery_year(client):
    r = client.post("/score", json={"listing_id": "X-1", "status": "future", "documents": []}, headers=H)
    codes = {f["code"] for f in r.json()["flags"]}
    assert "future_without_delivery_year" in codes and "missing_documents" in codes
    assert 0 <= r.json()["score"] < 100


def test_comply_shortfall_when_above_target(client):
    months = [{"month": f"2026-{m:02d}", "production_t": 100000, "power_kwh": 9_000_000, "coal_t": 9000} for m in range(4, 11)]
    r = client.post("/comply/forecast", json={"plant_id": "P-1", "target": 0.01, "months": months}, headers=H)
    assert r.status_code == 200, r.text
    assert r.json()["shortfall_t"]["likely"] > 0


def test_prices(client):
    r = client.get("/prices?method=removal&vintage=2025", headers=H)
    assert r.status_code == 200 and r.json()["series"]


def test_traders_only_get_voluntary():
    assert {x["market"] for x in tools.search_listings({}, "trader")["listings"]} == {"voluntary"}
    assert {x["market"] for x in tools.search_listings({}, "obligated")["listings"]} == {"india_compliance"}


def test_small_plot_offset_fees_exceed_money():
    routes = {r["route"]: r for r in tools.route_costs(1.0, 8.0)["routes"]}
    assert routes["india_offset"]["fixed_costs_exceed_likely_money"] is True


def test_knowledge_lookup_finds_obligated_entity():
    titles = [p["title"].lower() for p in tools.knowledge_lookup("what is an obligated entity")["passages"]]
    assert any("obligated" in t for t in titles)


def test_growth_ranges_are_ordered_and_add_up():
    est = growth.estimate("melia_dubia", area_ha=1.0, years=10)
    for row in est["per_year"]:
        assert 0 <= row["co2_t"]["low"] <= row["co2_t"]["likely"] <= row["co2_t"]["high"]
    assert est["total_co2_t"]["likely"] > 0


def _rpc(client, method, params=None, key="test-mcp-key"):
    body = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params or {}}
    return client.post("/mcp", json=body, headers={**MCP_H, "X-API-Key": key})


def test_mcp_lists_all_nine_tools(client):
    r = _rpc(client, "tools/list")
    assert r.status_code == 200, r.text
    names = {t["name"] for t in r.json()["result"]["tools"]}
    assert names == {"scan_land", "score_listing", "comply_forecast", "price_series", "search_listings",
                     "claim_rules", "banned_words", "knowledge_lookup", "route_costs"}


def test_mcp_tool_call_passes_arguments(client):
    r = _rpc(client, "tools/call", {"name": "route_costs", "arguments": {"area_ha": 2.0, "credits_per_year_likely": 10}})
    assert r.status_code == 200, r.text
    result = r.json()["result"]
    assert result["structuredContent"]["area_ha"] == 2.0


def test_mcp_refuses_wrong_key(client):
    assert _rpc(client, "tools/list", key="wrong").status_code == 401
